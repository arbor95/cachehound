package ewe.io;
import ewe.util.*;

//##################################################################
public class ObjectStreamException extends IOException{
//##################################################################

public ObjectStreamException() {super();}
public ObjectStreamException(String message) {super(message);}

//##################################################################
}
//##################################################################

