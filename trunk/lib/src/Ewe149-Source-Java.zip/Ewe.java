public class Ewe {

public static void main(String args[]) throws Exception
{
	ewe.applet.Applet.main(args);
}

}
